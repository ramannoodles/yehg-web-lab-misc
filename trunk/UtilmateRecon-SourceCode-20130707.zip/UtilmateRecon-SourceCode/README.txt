Ultimate Web Recon Source Code (c) YGN Ethical Hacker Group

Released under GPLv3

We wish your contribution to be beneficial to the community and to save time of re-inventing the wheel.
The program was developed using Visual Studio 2012 and it would require Microsoft.Net Framework 4.0+.


Regards
YGN Ethical Hacker Group
http://yehg.net/
2013-07-07