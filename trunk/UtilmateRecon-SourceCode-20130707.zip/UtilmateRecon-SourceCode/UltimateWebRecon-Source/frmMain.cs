﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Collections;
using System.Net;

namespace UtilmateRecon
{

    public partial class frmMain : Form
    {
        string prog_name = "Ultimate Web Recon";
        string file_recon = "reconDb.xml";
        string prog_version = "v2013-05-12";
        string prog_compatibility = "hellion";
        XDocument xDoc;

        public frmMain()
        {
            InitializeComponent();
            Reload_Db();
            BuildMenuItems();
            checkForProgramUpdate();
        }
        private void BuildMenuItems()
        {
            List<string> cats = search_xmlfile_cat();
            // for each category
            foreach (string c in cats)
            {
                // get link name in each category
                // link name will be sub menu
                List<string> mList = search_xmlfile_link_from_cat(c);
                ToolStripMenuItem[] mitems = new ToolStripMenuItem[mList.Count];
                int i = 0;
                foreach (string ml in mList)
                {
                    mitems[i] = new ToolStripMenuItem();
                    mitems[i].Name = ml + i.ToString();
                    mitems[i].Text = ml.Trim();
                    mitems[i].Click += new EventHandler(MenuItemClickHandler);
                    i++;
                }
                i = 0;

                switch (c)
                {
                    case "DNS":
                        DNSToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    case "Exploits":
                        ExploitsToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    case "GHDB":
                        GHDBToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Availability":
                        AvailabilityToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Web":
                        WebUtilitiesToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Encoders":
                        encodersToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Malware":
                        malwareToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Tools":
                        toolsToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Crack":
                        CrackToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Company":
                        CompanyToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "People":
                        PeopleToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "X-Ref":
                        xRefToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Resources":
                        ResourcesToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    case "MetaData":
                        metaDataToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    default:
                        MessageBox.Show("New program update may have been released. \r\n\r\nThe Download URL will be placed in Query text field for your convenience to download.\r\n\r\nCheers\r\nYGN Ethical Hacker Group",this.prog_name + " Update");
                        txtQuery.Text = "https://yehg-web-lab-misc.googlecode.com/svn/trunk/reconDb/program/";
                        break;

                }


            }

        }
        private void ReBuildMenuItems()
        {
            // Clear menu
            DNSToolStripMenuItem.DropDownItems.Clear();
            ExploitsToolStripMenuItem.DropDownItems.Clear();
            GHDBToolStripMenuItem.DropDownItems.Clear();
            AvailabilityToolStripMenuItem.DropDownItems.Clear();
            WebUtilitiesToolStripMenuItem.DropDownItems.Clear();
            encodersToolStripMenuItem.DropDownItems.Clear();
            malwareToolStripMenuItem.DropDownItems.Clear();
            toolsToolStripMenuItem.DropDownItems.Clear();
            CrackToolStripMenuItem.DropDownItems.Clear();
            CompanyToolStripMenuItem.DropDownItems.Clear();
            PeopleToolStripMenuItem.DropDownItems.Clear();
            xRefToolStripMenuItem.DropDownItems.Clear();
            ResourcesToolStripMenuItem.DropDownItems.Clear();
            metaDataToolStripMenuItem.DropDownItems.Clear();

            List<string> cats = search_xmlfile_cat();
            // for each category
            foreach (string c in cats)
            {
                // get link name in each category
                // link name will be sub menu
                List<string> mList = search_xmlfile_link_from_cat(c);
                ToolStripMenuItem[] mitems = new ToolStripMenuItem[mList.Count];
                int i = 0;
                foreach (string ml in mList)
                {
                    mitems[i] = new ToolStripMenuItem();
                    mitems[i].Name = ml + i.ToString();
                    mitems[i].Text = ml.Trim();
                    mitems[i].Click += new EventHandler(MenuItemClickHandler);
                    i++;
                }
                i = 0;

                switch (c)
                {
                    case "DNS":
                        DNSToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    case "Exploits":
                        ExploitsToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    case "GHDB":
                        GHDBToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Availability":
                        AvailabilityToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Web":
                        WebUtilitiesToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Encoders":
                        encodersToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Malware":
                        malwareToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Tools":
                        toolsToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Crack":
                        CrackToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Company":
                        CompanyToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "People":
                        PeopleToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "X-Ref":
                        xRefToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;

                    case "Resources":
                        ResourcesToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    case "MetaData":
                        metaDataToolStripMenuItem.DropDownItems.AddRange(mitems);
                        break;
                    default:
                        MessageBox.Show("New program update may have been released. \r\n\r\nThe Download URL will be placed in Query text field for your convenience to download.\r\n\r\nCheers\r\nYGN Ethical Hacker Group",this.prog_name);
                        txtQuery.Text = "https://yehg-web-lab-misc.googlecode.com/svn/trunk/reconDb/program/";
                        break;

                }


            }

        }
        private void MenuItemClickHandler(object sender, EventArgs e)
        {
            ToolStripMenuItem clickedItem = (ToolStripMenuItem)sender;
            if (clickedItem.Tag != "Recent")
            {
                if (RecentToolStripMenuItem.DropDownItems.ContainsKey(clickedItem.Text.Trim()))
                {
                    // Duplicate, skip adding
                }
                else
                {
                    var new_recent_item = new ToolStripMenuItem();
                    new_recent_item.Name = clickedItem.Text.Trim();
                    new_recent_item.Text = clickedItem.Text.Trim();
                    new_recent_item.Tag = "Recent";
                    new_recent_item.Click += new EventHandler(MenuItemClickHandler);
                    RecentToolStripMenuItem.DropDownItems.Add(new_recent_item);
                }
            }
            doQuery(sender, "");
        }
        private void Reload_Db() 
        {
            try
            {
                xDoc = XDocument.Load(file_recon);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Check the syntax of the " + file_recon + " XML file.\r\n\r\n-------------------- Stack Trace ---------------------\r\n" + ex.ToString(), "ERROR");
                Application.Exit();
            }        
        }

        /// <summary>
        /// //// Get Link from XML file 
        /// </summary>
        /// <param name="sitename"></param>
        /// <returns>String</returns>
        /// 
        private string get_link(string sitename)
        {
            string link = "";
            link = search_xmlfile(sitename);
            return link;
        }
        // Get link value by default
        private string search_xmlfile(string sitename, string attribute="value")
        {
            string xval = "";
            try
            {
                var result = from link in xDoc.Element("links").Descendants("link")
                             where link.Attribute("name").Value == sitename
                             select link.Attribute(attribute).Value;

                foreach (var subitem in result)
                {
                    xval = subitem;
                }
                if (xval == "" && attribute != "ontextfield")
                {
                    MessageBox.Show("The associated link for " + sitename + " with attribute " + attribute + " cannot be found in the XML file!\r\nGoing to the default site..", "ERROR");
                    xval = "http://yehg.net/";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
            return xval;
        }
        // Get all categories
        private List<string> search_xmlfile_cat()
        {
            List<string> xval = new List<string>();
            var result = from link in xDoc.Element("links").Descendants("category")
                         select link.Attribute("name").Value ;

            foreach (var item in result)
            {
                if (item.ToLower() != "info")
                {
                    xval.Add(item);
                }
            }
            return xval;
        }
        // Get all link names in each category
        private List<string> search_xmlfile_link_from_cat(string onecat)
        {
            List<string> xval = new List<string>();

            var result = (from link in xDoc.Descendants("category").Elements("link") 
                          where link.Parent.Attribute("name").Value == onecat 
                          where link.Attribute("compatible").Value == "yes"
                          select link.Attribute("name").Value).ToList();
            
            foreach (var item in result)
            {
                 xval.Add(item);
            }            
            return xval;
        }
        
        private void alert(String s) 
        {
            MessageBox.Show(s, this.prog_name);
        }

        private void createWebTab(string tabName, string target, string url)
        {
            TabPage tabPg = new TabPage();
            tabPg.Text = tabName + " - " + txtQuery.Text;
            tabPg.AllowDrop = true;

            ToolStrip ts = new ToolStrip();
            ts.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            ts.Dock = DockStyle.Top;

            ToolStripSpringTextBox ToolStripTextBoxURL = new ToolStripSpringTextBox();
            ToolStripTextBoxURL.Text = url;
            ts.Items.Add(ToolStripTextBoxURL);

            ToolStripButton ToolStripButtonGoURL = new ToolStripButton(" Go! ");
            ToolStripButtonGoURL.Click += new EventHandler(ToolStripButtonGoURL_Click);
            ts.Items.Add(ToolStripButtonGoURL);

            ToolStripButton ToolStripButtonGoBackURL = new ToolStripButton(" << ");
            ToolStripButtonGoBackURL.ToolTipText = "Go Back to one history if you have navigated to and fro";
            ToolStripButtonGoBackURL.Click += new EventHandler(ToolStripButtonGoBackURL_Click);
            ts.Items.Add(ToolStripButtonGoBackURL);

            ToolStripButton ToolStripButtonGoForwardURL = new ToolStripButton(" >> ");
            ToolStripButtonGoForwardURL.ToolTipText = "Go Forward to one history if you have navigated to and fro";
            ToolStripButtonGoForwardURL.Click += new EventHandler(ToolStripButtonGoForwardURL_Click);
            ts.Items.Add(ToolStripButtonGoForwardURL);

            ToolStripSeparator ToolStripSeparator1 = new ToolStripSeparator();
            ts.Items.Add(ToolStripSeparator1);

            ToolStripButton ToolStripButtonCopyURL = new ToolStripButton(" Copy URL ");
            ToolStripButtonCopyURL.Click += new EventHandler(ToolStripButtonCopyURL_Click);
            ts.Items.Add(ToolStripButtonCopyURL);

            ToolStripSeparator ToolStripSeparator2 = new ToolStripSeparator();
            ts.Items.Add(ToolStripSeparator2);

            ToolStripButton ToolStripButtonSave = new ToolStripButton(" Save ");
            ToolStripButtonSave.Click += new EventHandler(ToolStripButtonSave_Click);
            ts.Items.Add(ToolStripButtonSave);

            ToolStripSeparator ToolStripSeparator3 = new ToolStripSeparator();
            ts.Items.Add(ToolStripSeparator3);

            ToolStripButton ToolStripButtonClose = new ToolStripButton(" Close ");
            ToolStripButtonClose.Click += new EventHandler(ToolStripButtonClose_Click);
            ts.Items.Add(ToolStripButtonClose);

            WebBrowser Browser = new WebBrowser();
            Browser.Tag = search_xmlfile(tabName, "ontextfield");
            Browser.ScriptErrorsSuppressed = true;
            Browser.Dock = DockStyle.Fill;
            Browser.Location = new System.Drawing.Point(0, 20);
            
            Browser.ScrollBarsEnabled = true;
            Browser.Navigating += new WebBrowserNavigatingEventHandler(HtmlDocument_Loading);
            //Browser.Navigated += new WebBrowserNavigatedEventHandler(HtmlDocument_Navigated);
            Browser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(HtmlDocument_Loaded);

            tabPg.Controls.Add(Browser); // tabpage [0]
            tabPg.Controls.Add(ts);   // tabpage [1]

            tabCtrl.TabPages.Add(tabPg); 
            tabCtrl.SelectedTab = tabPg;

            Browser.Navigate(new Uri(url));

            while (Browser.ReadyState != WebBrowserReadyState.Complete)
            {
                Application.DoEvents();
            }
            loadingPic.Hide();  
        }
        private void HtmlDocument_Loaded(object sender, WebBrowserDocumentCompletedEventArgs e)
        {            
            string url = e.Url.ToString();
            
            var Browser = (WebBrowser)sender;    
            var onTextField = (String) Browser.Tag;

            TabPage tb = (TabPage)(Browser.Parent);
            ToolStrip ts = (ToolStrip)tb.Controls[1];
            ToolStripSpringTextBox textBoxURL = (ToolStripSpringTextBox)ts.Items[0];
            textBoxURL.Text = url;

            if (!(url.StartsWith("http://") || url.StartsWith("https://")))
            {
                // AJAX     
            }
            if (e.Url.AbsolutePath != Browser.Url.AbsolutePath)
            {
                // IFRAME           
            }
            else
            {
                // Main document
                if (onTextField != "" && onTextField !="all") {
                    
                    Browser.Document.GetElementById(onTextField).InnerText = txtQuery.Text;
                    Browser.Document.All.GetElementsByName(onTextField)[0].SetAttribute("value", txtQuery.Text);
                    // click button
                    // .GetElementById("submit").InvokeMember("click")

                    // with JavaScript - proven for input fields that have double name or ID defined or long page loading
                    // ie.<input class="containsHash" type="text" name="hashToSearch" maxlength="48" name="hashToSearch">

                    HtmlElement headElement = Browser.Document.GetElementsByTagName("body")[0];
                    HtmlElement scriptElement = Browser.Document.CreateElement("script");
                    scriptElement.SetAttribute("type", "text/javascript");
                    scriptElement.SetAttribute("text", "onload=function(){var element = document.getElementById('" + onTextField + "');if (element != null) {	document.getElementById('" + onTextField + "').value = '" + txtQuery.Text + "'; }else{	var element = document.getElementsByName('" + onTextField + "')[0];	if (element != null) {		document.getElementsByName('" + onTextField + "').value = '" + txtQuery.Text + "';	}}}");

                    headElement.AppendChild(scriptElement);
                }
                else if (onTextField == "all") {
                    HtmlElement headElement = Browser.Document.GetElementsByTagName("body")[0];
                    HtmlElement scriptElement = Browser.Document.CreateElement("script");
                    scriptElement.SetAttribute("type", "text/javascript");
                    scriptElement.SetAttribute("text", "onload=function(){	var input =  document.getElementsByTagName('input');if (input.length >= 1)	{for(var i=0;i<=input.length-1;i++)	{  if(document.getElementsByTagName('input')[i].type=='text')   {      document.getElementsByTagName('input')[i].value ='" + txtQuery.Text + "'; 	   }	}	}	}");

                    headElement.AppendChild(scriptElement);                
                
                }               
            }
            loadingPic.Hide();

        }
        private void HtmlDocument_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            loadingPic.Hide();
        }
        private void HtmlDocument_Loading(object sender, WebBrowserNavigatingEventArgs e)
        {
            string url = e.Url.ToString();
            if (url.StartsWith("res://")) {
                alert("ERROR in navigating the request URL. Try again later.\r\n\r\n----------------------------\r\nIE engine returned:\r\n" + url);
            }
            
            loadingPic.Show();
        }
        private void ToolStripButtonGoURL_Click(object sender, EventArgs e)
        {
            ToolStripButton t = (ToolStripButton)(sender);
            ToolStrip ts = t.Owner;
            TabPage tb = (TabPage)(ts.Parent);
            var ToolStripTextBox1 = (ToolStripTextBox)ts.Items[0];
            String updated_url = ToolStripTextBox1.Text;
            var Browser1 = (WebBrowser)tb.Controls[0];
            // already declared, pointer by reference 
            //Browser1.Navigating += new WebBrowserNavigatingEventHandler(HtmlDocument_Loading);
            //Browser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(HtmlDocument_Loaded);
            Browser1.Navigate(updated_url);
        }
        private void ToolStripButtonGoBackURL_Click(object sender, EventArgs e)
        {
            ToolStripButton t = (ToolStripButton)(sender);
            ToolStrip ts = t.Owner;
            TabPage tb = (TabPage)(ts.Parent);
            var ToolStripTextBox1 = (ToolStripTextBox)ts.Items[0];
            String updated_url = ToolStripTextBox1.Text;
            var Browser1 = ((WebBrowser)tb.Controls[0]);
            // already declared, pointer by reference 
            //Browser1.Navigating += new WebBrowserNavigatingEventHandler(HtmlDocument_Loading);
            //Browser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(HtmlDocument_Loaded);
            Browser1.GoBack();
        }
        private void ToolStripButtonGoForwardURL_Click(object sender, EventArgs e)
        {
            ToolStripButton t = (ToolStripButton)(sender);
            ToolStrip ts = t.Owner;
            TabPage tb = (TabPage)(ts.Parent);
            var ToolStripTextBox1 = (ToolStripTextBox)ts.Items[0];
            String updated_url = ToolStripTextBox1.Text;
            var Browser1 = (WebBrowser)tb.Controls[0];
            // already declared, pointer by reference 
            //Browser1.Navigating += new WebBrowserNavigatingEventHandler(HtmlDocument_Loading);
            //Browser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(HtmlDocument_Loaded);
            Browser1.GoForward();
        }     
        private void ToolStripButtonClose_Click(object sender, EventArgs e)
        {
            try
            {
                loadingPic.Hide();
                ToolStripButton t = (ToolStripButton)(sender);
                ToolStrip ts = t.Owner;
                TabPage tp = (TabPage)(ts.Parent);
                while (tp.Controls.Count > 0)
                {
                    if (tp.Controls[0].GetType().ToString() == "System.Windows.Forms.WebBrowser") {
                        var b = (WebBrowser)tp.Controls[0];
                        b.Navigating -= HtmlDocument_Loading;
                        b.DocumentCompleted -= HtmlDocument_Loaded;
                    }
                    tp.Controls.RemoveAt(0);
                    tp.Controls[0].Dispose();                    
                }
                tp.Dispose();
                tabCtrl.TabPages.Remove(tp);
                tabCtrl.SelectedIndex = tabCtrl.TabPages.Count - 1;
            }
            catch (Exception ex) {
               // alert(ex.ToString());
            }
        }
        private void ToolStripButtonSave_Click(object sender, EventArgs e)
        {
            ToolStripButton t = (ToolStripButton)(sender);
            ToolStrip ts = t.Owner;
            TabPage tb = (TabPage)(ts.Parent);
            var Browser1 = (WebBrowser)tb.Controls[0];
            Browser1.ShowSaveAsDialog();
        }
        private void ToolStripButtonCopyURL_Click(object sender, EventArgs e)
        {
            ToolStripButton t = (ToolStripButton)(sender);
            ToolStrip ts = t.Owner;
            TabPage tb = (TabPage)(ts.Parent);
            var ToolStripTextBox1 = (ToolStripTextBox)ts.Items[0];
            Clipboard.SetText(ToolStripTextBox1.Text);
        }



        private Boolean CheckInput(TextBox txtbx, String text)
        {
            if (txtbx.Text.Length == 0)
            {
                MessageBox.Show(text, "Error: Information Needed");
                txtbx.Focus();
                return false;
            }
            return true;
        }

        private string prepareQuery(string url, string seed)
        {
            return url.Replace("%s", seed);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            lblAbout.Text = "Ultimate Web Recon\r\n\r\n" + "Program version: " + prog_version + "\r\nDatatabse version: " + search_xmlfile("lastupdate") + "\r\n\r\nCoded by\r\nYGN Ethical Hacker Group\r\nYangon, Myanmar\r\nhttp://yehg.net/\r\n";
        }
        private void checkForProgramUpdate()
        {
            String nprog_version = search_xmlfile("compatible_program_version");
            if (nprog_version != this.prog_compatibility.ToString())
            {
                MessageBox.Show("New program update may have been released. Download UltimateWebRecon.exe in the update tab. \r\n\r\nCheers\r\nYGN Ethical Hacker Group", this.prog_name + " Update");
                txtQuery.Text = "https://yehg-web-lab-misc.googlecode.com/svn/trunk/UltimateWebRecon/";
                createWebTab(this.prog_name + " Update", "", txtQuery.Text);
            }
        }
        private void doQuery(object sender, string required) {
            String query = "";
            ToolStripMenuItem tm = (ToolStripMenuItem)sender;
            if (required == "")
            {
                if (CheckInput(txtQuery, "Fill in the Query text field."))
                {
                    query = txtQuery.Text; createWebTab(tm.Text, query, prepareQuery(get_link(tm.Text), query));
                }
            }
            else {
                createWebTab(tm.Text, query,get_link(tm.Text));
            }            
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This simple program was developed by YGN Ethical Hacker Group.\r\n\r\n" + "Program version: " + prog_version + "\r\nDatatabse version: " + search_xmlfile("lastupdate") + "\r\n\r\nWant to add new cool link? Send it to tool@yehg.net.\r\n", "About " + this.prog_name);
        }

        private void reloadDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Reload_Db();
            ReBuildMenuItems();
            checkForProgramUpdate();
        }

        private void btnGoogle_Click(object sender, EventArgs e)
        {
            if (txtQuery.Text.Length < 1)
            {
                MessageBox.Show("Nothing to Google!", this.prog_name);
            }
            else
            {
                createWebTab(txtQuery.Text, "Google", prepareQuery("https://www.google.com/search?q=%s", txtQuery.Text));
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            if (txtQuery.Text.Length < 1)
            {
                MessageBox.Show("Nowhere to Go!", this.prog_name);
            }
            else
            {
                createWebTab(txtQuery.Text, "", txtQuery.Text);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void reportBugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello\r\n\r\nWe appreciate your time. Please send your detailed problem information to bug@yehg.net.\r\n\r\nCheers\r\nYGN Ethical Hacker Group.\r\n", "Report Bug");
        }

        private void checkForDatabaseUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Existing Database file will be ovewritten.\r\nBack it up if you've made some changes. \r\nContinue? ", "Update Warning", MessageBoxButtons.YesNo)
            == DialogResult.No)
            {
                return;
            }

            WebClient webClient = new WebClient();
            String file_reconDb_tmp = "reconDb.xml.tmp";

            // Download
            try
            {
                String nocache = Path.GetRandomFileName();
                webClient.DownloadFile("https://yehg-web-lab-misc.googlecode.com/svn/trunk/UltimateWebRecon/reconDb.xml?" + nocache, file_reconDb_tmp);
            }
            catch (Exception ex) {
                MessageBox.Show("An error has occurred.\r\n\r\n------------------------------\r\n" + ex.Message.ToString(), this.prog_name);
                return;
            }

            // Check syntax
            XDocument xD;
            try
            {
                xD = XDocument.Load(file_reconDb_tmp);
            }
            catch (Exception ex)
            {
                MessageBox.Show("The remote database file download has been corrupted.\r\nPlease download it again later.\r\n\r\n-------------------- Stack Trace ---------------------\r\n" + ex.ToString(), "ERROR");
                return;
            }  
            // Delete existing db file
            File.Delete(file_recon);

            // Rename downloaded db file
            File.Move(file_reconDb_tmp, file_recon);

            string old_lastupdate = search_xmlfile("lastupdate");
            Reload_Db();
            ReBuildMenuItems();
            string new_lastupdate = search_xmlfile("lastupdate");
            if (old_lastupdate != new_lastupdate)
            {
                MessageBox.Show("The Web Recon Database file has been updated!\r\nNew Database version: " + search_xmlfile("lastupdate") + "\r\n\r\nCheers\r\nYGN Ethical Hacker Group\r\n", this.prog_name + " Update");
            }
            else
            {
                MessageBox.Show("No new database update for the time being!\r\n\r\nCheers\r\nYGN Ethical Hacker Group\r\n", this.prog_name + " Update");
            }
            checkForProgramUpdate();
            
            lblAbout.Text = "Ultimate Web Recon\r\n\r\n" + "Program version: " + prog_version + "\r\nDatatabse version: " + search_xmlfile("lastupdate") + "\r\n\r\nCoded by\r\nYGN Ethical Hacker Group\r\nYangon, Myanmar\r\nhttp://yehg.net/\r\n";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtQuery.Clear();
            txtQuery.Focus();
        }

        private void licenseToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This program is licensed to \r\n\r\n" + Environment.UserName.ToUpper() + "\r\n\r\n\r\nFreeware License\r\n============== \r\n\r\nThe program is distributed in the hope that it will be useful, but without any warranty. It is provided \"AS IS\" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. Should the program prove defective, you assume the cost of all necessary servicing, repair or correction. \r\n\r\nIn no event YGN Ethical Hacker Group will be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs), even if YGN Ethical Hacker Group has been advised of the possibility of such damages.\r\n", "About " + this.prog_name + " License");            
        }

        private void btnPaste_Click(object sender, EventArgs e)
        {
            txtQuery.Text = Clipboard.GetText();
        }
    }

    // credit: http://msdn.microsoft.com/en-us/library/ms404304.aspx
    public class ToolStripSpringTextBox : ToolStripTextBox
    {
        public override Size GetPreferredSize(Size constrainingSize)
        {
            if (IsOnOverflow || Owner.Orientation == Orientation.Vertical)
            {
                return DefaultSize;
            }
            Int32 width = Owner.DisplayRectangle.Width;
            if (Owner.OverflowButton.Visible)
            {
                width = width - Owner.OverflowButton.Width -
                    Owner.OverflowButton.Margin.Horizontal;
            }
            Int32 springBoxCount = 0;

            foreach (ToolStripItem item in Owner.Items)
            {
                if (item.IsOnOverflow) continue;

                if (item is ToolStripSpringTextBox)
                {
                    springBoxCount++;
                    width -= item.Margin.Horizontal;
                }
                else
                {
                    width = width - item.Width - item.Margin.Horizontal;
                }
            }
            if (springBoxCount > 1) width /= springBoxCount;
            if (width < DefaultSize.Width) width = DefaultSize.Width;
            Size size = base.GetPreferredSize(constrainingSize);
            size.Width = width;
            return size;
        }
    }

}
