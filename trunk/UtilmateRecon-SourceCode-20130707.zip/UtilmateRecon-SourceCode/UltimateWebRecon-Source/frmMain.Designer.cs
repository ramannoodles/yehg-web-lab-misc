﻿namespace UtilmateRecon
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tabCtrl = new System.Windows.Forms.TabControl();
            this.tabpgInfo = new System.Windows.Forms.TabPage();
            this.logoYEHG = new System.Windows.Forms.PictureBox();
            this.lblAbout = new System.Windows.Forms.Label();
            this.txtQuery = new System.Windows.Forms.TextBox();
            this.lblQuery = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.RecentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DNSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AvailabilityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GHDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExploitsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xRefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WebUtilitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CrackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encodersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CompanyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PeopleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metaDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ResourcesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportBugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reloadDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkForDatabaseUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.licenseToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnGoogle = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.loadingPic = new System.Windows.Forms.PictureBox();
            this.btnPaste = new System.Windows.Forms.Button();
            this.tabCtrl.SuspendLayout();
            this.tabpgInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoYEHG)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loadingPic)).BeginInit();
            this.SuspendLayout();
            // 
            // tabCtrl
            // 
            this.tabCtrl.Controls.Add(this.tabpgInfo);
            this.tabCtrl.Location = new System.Drawing.Point(86, 43);
            this.tabCtrl.Name = "tabCtrl";
            this.tabCtrl.SelectedIndex = 0;
            this.tabCtrl.Size = new System.Drawing.Size(1010, 678);
            this.tabCtrl.TabIndex = 0;
            // 
            // tabpgInfo
            // 
            this.tabpgInfo.AllowDrop = true;
            this.tabpgInfo.AutoScroll = true;
            this.tabpgInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tabpgInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabpgInfo.Controls.Add(this.logoYEHG);
            this.tabpgInfo.Controls.Add(this.lblAbout);
            this.tabpgInfo.Location = new System.Drawing.Point(4, 22);
            this.tabpgInfo.Name = "tabpgInfo";
            this.tabpgInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tabpgInfo.Size = new System.Drawing.Size(1002, 652);
            this.tabpgInfo.TabIndex = 0;
            this.tabpgInfo.Text = "About";
            this.tabpgInfo.UseVisualStyleBackColor = true;
            // 
            // logoYEHG
            // 
            this.logoYEHG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.logoYEHG.Image = ((System.Drawing.Image)(resources.GetObject("logoYEHG.Image")));
            this.logoYEHG.Location = new System.Drawing.Point(750, 17);
            this.logoYEHG.Name = "logoYEHG";
            this.logoYEHG.Size = new System.Drawing.Size(244, 92);
            this.logoYEHG.TabIndex = 5;
            this.logoYEHG.TabStop = false;
            // 
            // lblAbout
            // 
            this.lblAbout.AutoSize = true;
            this.lblAbout.Location = new System.Drawing.Point(6, 13);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(35, 13);
            this.lblAbout.TabIndex = 4;
            this.lblAbout.Text = "About";
            // 
            // txtQuery
            // 
            this.txtQuery.AllowDrop = true;
            this.txtQuery.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtQuery.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQuery.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuery.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.txtQuery.Location = new System.Drawing.Point(128, 14);
            this.txtQuery.Name = "txtQuery";
            this.txtQuery.Size = new System.Drawing.Size(557, 22);
            this.txtQuery.TabIndex = 1;
            this.txtQuery.Text = "google.com";
            // 
            // lblQuery
            // 
            this.lblQuery.AutoSize = true;
            this.lblQuery.Location = new System.Drawing.Point(84, 19);
            this.lblQuery.Name = "lblQuery";
            this.lblQuery.Size = new System.Drawing.Size(38, 13);
            this.lblQuery.TabIndex = 6;
            this.lblQuery.Text = "Query:";
            this.lblQuery.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RecentToolStripMenuItem,
            this.DNSToolStripMenuItem,
            this.AvailabilityToolStripMenuItem,
            this.GHDBToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.ExploitsToolStripMenuItem,
            this.xRefToolStripMenuItem,
            this.WebUtilitiesToolStripMenuItem,
            this.CrackToolStripMenuItem,
            this.encodersToolStripMenuItem,
            this.malwareToolStripMenuItem,
            this.CompanyToolStripMenuItem,
            this.PeopleToolStripMenuItem,
            this.metaDataToolStripMenuItem,
            this.ResourcesToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Margin = new System.Windows.Forms.Padding(0, 9, 0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(6, 15, 0, 2);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(98, 721);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "mnu";
            // 
            // RecentToolStripMenuItem
            // 
            this.RecentToolStripMenuItem.Name = "RecentToolStripMenuItem";
            this.RecentToolStripMenuItem.Size = new System.Drawing.Size(55, 19);
            this.RecentToolStripMenuItem.Text = "Recent";
            // 
            // DNSToolStripMenuItem
            // 
            this.DNSToolStripMenuItem.Name = "DNSToolStripMenuItem";
            this.DNSToolStripMenuItem.Size = new System.Drawing.Size(42, 19);
            this.DNSToolStripMenuItem.Text = "DNS";
            // 
            // AvailabilityToolStripMenuItem
            // 
            this.AvailabilityToolStripMenuItem.Name = "AvailabilityToolStripMenuItem";
            this.AvailabilityToolStripMenuItem.Size = new System.Drawing.Size(77, 19);
            this.AvailabilityToolStripMenuItem.Text = "Availability";
            // 
            // GHDBToolStripMenuItem
            // 
            this.GHDBToolStripMenuItem.Name = "GHDBToolStripMenuItem";
            this.GHDBToolStripMenuItem.Size = new System.Drawing.Size(51, 19);
            this.GHDBToolStripMenuItem.Text = "GHDB";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(48, 19);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // ExploitsToolStripMenuItem
            // 
            this.ExploitsToolStripMenuItem.Name = "ExploitsToolStripMenuItem";
            this.ExploitsToolStripMenuItem.Size = new System.Drawing.Size(59, 19);
            this.ExploitsToolStripMenuItem.Text = "Exploits";
            // 
            // xRefToolStripMenuItem
            // 
            this.xRefToolStripMenuItem.Name = "xRefToolStripMenuItem";
            this.xRefToolStripMenuItem.Size = new System.Drawing.Size(48, 19);
            this.xRefToolStripMenuItem.Text = "X-Ref";
            // 
            // WebUtilitiesToolStripMenuItem
            // 
            this.WebUtilitiesToolStripMenuItem.Name = "WebUtilitiesToolStripMenuItem";
            this.WebUtilitiesToolStripMenuItem.Size = new System.Drawing.Size(43, 19);
            this.WebUtilitiesToolStripMenuItem.Text = "Web";
            // 
            // CrackToolStripMenuItem
            // 
            this.CrackToolStripMenuItem.Name = "CrackToolStripMenuItem";
            this.CrackToolStripMenuItem.Size = new System.Drawing.Size(49, 19);
            this.CrackToolStripMenuItem.Text = "Crack";
            // 
            // encodersToolStripMenuItem
            // 
            this.encodersToolStripMenuItem.Name = "encodersToolStripMenuItem";
            this.encodersToolStripMenuItem.Size = new System.Drawing.Size(67, 19);
            this.encodersToolStripMenuItem.Text = "Encoders";
            // 
            // malwareToolStripMenuItem
            // 
            this.malwareToolStripMenuItem.Name = "malwareToolStripMenuItem";
            this.malwareToolStripMenuItem.Size = new System.Drawing.Size(64, 19);
            this.malwareToolStripMenuItem.Text = "Malware";
            // 
            // CompanyToolStripMenuItem
            // 
            this.CompanyToolStripMenuItem.Name = "CompanyToolStripMenuItem";
            this.CompanyToolStripMenuItem.Size = new System.Drawing.Size(71, 19);
            this.CompanyToolStripMenuItem.Text = "Company";
            // 
            // PeopleToolStripMenuItem
            // 
            this.PeopleToolStripMenuItem.Name = "PeopleToolStripMenuItem";
            this.PeopleToolStripMenuItem.Size = new System.Drawing.Size(55, 19);
            this.PeopleToolStripMenuItem.Text = "People";
            // 
            // metaDataToolStripMenuItem
            // 
            this.metaDataToolStripMenuItem.Name = "metaDataToolStripMenuItem";
            this.metaDataToolStripMenuItem.Size = new System.Drawing.Size(70, 19);
            this.metaDataToolStripMenuItem.Text = "MetaData";
            // 
            // ResourcesToolStripMenuItem
            // 
            this.ResourcesToolStripMenuItem.Name = "ResourcesToolStripMenuItem";
            this.ResourcesToolStripMenuItem.Size = new System.Drawing.Size(72, 19);
            this.ResourcesToolStripMenuItem.Text = "Resources";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportBugToolStripMenuItem,
            this.reloadDatabaseToolStripMenuItem,
            this.checkForDatabaseUpdateToolStripMenuItem,
            this.licenseToolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 19);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // reportBugToolStripMenuItem
            // 
            this.reportBugToolStripMenuItem.Name = "reportBugToolStripMenuItem";
            this.reportBugToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.reportBugToolStripMenuItem.Text = "Report Bug";
            this.reportBugToolStripMenuItem.Click += new System.EventHandler(this.reportBugToolStripMenuItem_Click);
            // 
            // reloadDatabaseToolStripMenuItem
            // 
            this.reloadDatabaseToolStripMenuItem.Name = "reloadDatabaseToolStripMenuItem";
            this.reloadDatabaseToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.reloadDatabaseToolStripMenuItem.Text = "Reload Database";
            this.reloadDatabaseToolStripMenuItem.Click += new System.EventHandler(this.reloadDatabaseToolStripMenuItem_Click);
            // 
            // checkForDatabaseUpdateToolStripMenuItem
            // 
            this.checkForDatabaseUpdateToolStripMenuItem.Name = "checkForDatabaseUpdateToolStripMenuItem";
            this.checkForDatabaseUpdateToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.checkForDatabaseUpdateToolStripMenuItem.Text = "Update Database";
            this.checkForDatabaseUpdateToolStripMenuItem.Click += new System.EventHandler(this.checkForDatabaseUpdateToolStripMenuItem_Click);
            // 
            // licenseToolStripMenuItem1
            // 
            this.licenseToolStripMenuItem1.Name = "licenseToolStripMenuItem1";
            this.licenseToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.licenseToolStripMenuItem1.Text = "License";
            this.licenseToolStripMenuItem1.Click += new System.EventHandler(this.licenseToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 19);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // btnGoogle
            // 
            this.btnGoogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGoogle.Location = new System.Drawing.Point(739, 14);
            this.btnGoogle.Name = "btnGoogle";
            this.btnGoogle.Size = new System.Drawing.Size(60, 23);
            this.btnGoogle.TabIndex = 3;
            this.btnGoogle.Text = "Google";
            this.btnGoogle.UseVisualStyleBackColor = true;
            this.btnGoogle.Click += new System.EventHandler(this.btnGoogle_Click);
            // 
            // btnGo
            // 
            this.btnGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGo.Location = new System.Drawing.Point(691, 14);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(42, 23);
            this.btnGo.TabIndex = 2;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // btnExit
            // 
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Location = new System.Drawing.Point(934, 14);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(53, 23);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Location = new System.Drawing.Point(871, 14);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(57, 23);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // loadingPic
            // 
            this.loadingPic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.loadingPic.Image = ((System.Drawing.Image)(resources.GetObject("loadingPic.Image")));
            this.loadingPic.Location = new System.Drawing.Point(1047, 12);
            this.loadingPic.Name = "loadingPic";
            this.loadingPic.Size = new System.Drawing.Size(38, 32);
            this.loadingPic.TabIndex = 11;
            this.loadingPic.TabStop = false;
            this.loadingPic.Visible = false;
            // 
            // btnPaste
            // 
            this.btnPaste.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaste.Location = new System.Drawing.Point(805, 14);
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.Size = new System.Drawing.Size(61, 23);
            this.btnPaste.TabIndex = 4;
            this.btnPaste.Text = "Paste";
            this.btnPaste.UseVisualStyleBackColor = true;
            this.btnPaste.Click += new System.EventHandler(this.btnPaste_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 721);
            this.Controls.Add(this.btnPaste);
            this.Controls.Add(this.loadingPic);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.btnGoogle);
            this.Controls.Add(this.lblQuery);
            this.Controls.Add(this.txtQuery);
            this.Controls.Add(this.tabCtrl);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ultimate Web Recon -  YGN Ethical Hacker Group";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.tabCtrl.ResumeLayout(false);
            this.tabpgInfo.ResumeLayout(false);
            this.tabpgInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoYEHG)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loadingPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtrl;
        private System.Windows.Forms.TabPage tabpgInfo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem DNSToolStripMenuItem;
        private System.Windows.Forms.Label lblQuery;
        private System.Windows.Forms.ToolStripMenuItem AvailabilityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ResourcesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExploitsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CrackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xRefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem WebUtilitiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CompanyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PeopleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.TextBox txtQuery;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reloadDatabaseToolStripMenuItem;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.Button btnGoogle;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ToolStripMenuItem malwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encodersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem GHDBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportBugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkForDatabaseUpdateToolStripMenuItem;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ToolStripMenuItem metaDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem licenseToolStripMenuItem1;
        private System.Windows.Forms.PictureBox logoYEHG;
        private System.Windows.Forms.PictureBox loadingPic;
        private System.Windows.Forms.Button btnPaste;
        private System.Windows.Forms.ToolStripMenuItem RecentToolStripMenuItem;
    }
}

